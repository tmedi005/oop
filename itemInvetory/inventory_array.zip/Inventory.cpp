#include <utility>
#include "Inventory.h"

// Allow the compiler to define the remaining 
// comparison operators
using namespace std::rel_ops;

/**
 *
 */
Inventory::Inventory() {  
    this->slots    = 10;
    this->occupied = 0;

    this->items = new ItemStack[ slots ];
}

/**
 *
 */
Inventory::Inventory( int n ) {
    this->slots    = n;
    this->occupied = 0;

    this->items = new ItemStack[ slots ];
}

/**
 *
 */
bool Inventory::addItems( ItemStack stack ) {
    // Add the first ItemStack
    if( occupied == 0 ){
        this->items[0] = stack;
        occupied++;

        return true;
    }

    return false;
}

/**
 *
 */
void Inventory::display( std::ostream &outs ) const{

}